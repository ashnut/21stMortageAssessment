import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  validateLogin(formvalue:any):ILoginResult
  {
    let loginResult=new ILoginResult();
    loginResult.loginSuccessful=false;
    if(formvalue.email=="test@gmail.com" && formvalue.password=="pass@123")
      loginResult.loginSuccessful=true;
    return loginResult;
  }

}

export class ILoginResult {
  loginSuccessful: boolean;
  }
