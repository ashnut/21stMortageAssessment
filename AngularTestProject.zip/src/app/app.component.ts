import {Component, VERSION} from "@angular/core";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {LoginService} from "./loginService";

@Component({
  selector: "my-app",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {

  public loginForm: FormGroup;
  public submitted = false;
  public loginStatus = false;

  constructor(private formBuilder: FormBuilder, private router: Router, private login: LoginService) {
  }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ["", [Validators.email, Validators.required]],
      password: [
        "",
        [
          Validators.required
        ]
      ]
    });
  }

  get formControl() {
    return this.loginForm.controls;
  }

  onLogin(): void {
    this.submitted = true;
    if (this.loginForm.valid) {
      Promise.all([this.login.validateLogin(this.loginForm.value)]).then(resolvePromises => {
          this.loginStatus = resolvePromises[0].loginSuccessful;
        }
      );
    }
  }
}
